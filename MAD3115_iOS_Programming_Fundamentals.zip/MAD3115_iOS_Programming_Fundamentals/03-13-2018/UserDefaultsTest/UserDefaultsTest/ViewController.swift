//
//  ViewController.swift
//  UserDefaultsTest
//
//  Created by MacStudent on 2018-03-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        let defaults = UserDefaults.standard
        print(defaults)
        
        // add things to user defaults
        defaults.set(true, forKey: "wifiOn")
        defaults.set(0.59, forKey: "volume")
        defaults.set("Amu", forKey: "name")
        
        
        // get things out of user defaults
        let a = defaults.double(forKey: "volume")
        let b = defaults.string(forKey: "name")
        let c = defaults.bool(forKey: "wifiOn")
        print(a)
        print(b)
        print(c)
        
        // array
        let arr = ["apple","banana","carrot", "donut"]
        defaults.set(arr, forKey:"fruit")
        
        let d = defaults.array(forKey: "fruit") as! [String]
        print(d)
        
        // dictionaries
        let student = ["name":"Milan Kumar", "id":"C07994953", "program":"MADT"]
        defaults.set(student, forKey:"studentInfo")
        
        let e = defaults.dictionary(forKey: "studentInfo") as! Dictionary<String,String>    `
        
        print(e)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }


}

