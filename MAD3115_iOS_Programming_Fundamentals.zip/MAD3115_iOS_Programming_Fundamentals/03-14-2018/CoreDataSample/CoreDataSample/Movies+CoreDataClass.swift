//
//  Movies+CoreDataClass.swift
//  CoreDataSample
//
//  Created by MacStudent on 2018-03-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Movies)
public class Movies: NSManagedObject {

}
