//
//  ViewController.swift
//  TableViewExample
//
//  Created by MacStudent on 2018-03-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    //create a data source
    var movies = ["Black Panther","Avengers: Infinity War","Shape of the Water","Padmaavat","Thugs of Hindonston","Bahuballi 2"];
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //TableView related functions
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //Tell ios how many rows you want in your table
        return movies.count;
    }
    
    //Tell iOS what each cells looks like
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell",for: indexPath);
        
        //put some text in each row
        cell.textLabel?.text = movies[indexPath.row];
        return cell;
    }
    
    //Select an item in a tableView
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("Index ", indexPath.row," Value ", movies[indexPath.row]);
    }
    
    //Delete an item in a tableView
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        //Get the delete popup and delete the item you select
        if (editingStyle == .delete){
            print("Going to delete item ",movies[indexPath.row]);
            
            // delete from the array
            movies.remove(at: indexPath.row);
            
            //UI: delete from the tableView
            tableView.deleteRows(at: [indexPath], with: .automatic);
        }
        
        
    }

}


