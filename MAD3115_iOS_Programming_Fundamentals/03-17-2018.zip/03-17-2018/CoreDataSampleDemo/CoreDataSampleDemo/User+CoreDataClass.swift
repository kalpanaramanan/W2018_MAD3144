//
//  User+CoreDataClass.swift
//  CoreDataSampleDemo
//
//  Created by MacStudent on 2018-03-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
