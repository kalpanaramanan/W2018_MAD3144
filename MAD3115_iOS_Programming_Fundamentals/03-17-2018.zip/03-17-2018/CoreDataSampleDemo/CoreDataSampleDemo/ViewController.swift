//
//  ViewController.swift
//  CoreDataSampleDemo
//
//  Created by MacStudent on 2018-03-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var outputBox: UITextView!
    @IBOutlet weak var searchBox: UITextField!
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var databaseResults = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let path = FileManager.default.urls(for:.documentDirectory, in:.userDomainMask)
        print(path)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func saveButtonPressed(_ sender: UIButton) {
        // get the username and password from the text boxes
        let name = usernameTextField.text!
        let pass = passwordTextField.text!
        
        
        // create a new user
        let user = User(context: self.myContext)
        user.username = name
        user.password = pass
        
        // save the user to the database
        saveData()
        
        outputBox.text = "Saved \(name) to the database!"
    }
    
    
    
    @IBAction func loadButtonPressed(_ sender: UIButton) {
        
        
        outputBox.text = ""
        
        let request : NSFetchRequest<User> = User.fetchRequest()
        
        if (searchBox.text!.isEmpty == false) {
            
            //if the person typed something in the search box,
            // then build an SQL query based on that
            let query = NSPredicate(format: "username == %@", searchBox.text!)
            request.predicate = query
        }
        
        
        
        do {
            
            // run the query
            databaseResults = try myContext.fetch(request)
            
            
            // if there are no results to your query,
            // then let the user know
            if databaseResults.count == 0 {
                outputBox.text = "No results found!"
            }
            else {
                
                // otherwise, loop through all the results and show the names
                for u in databaseResults {
                    let name = u.username!
                    
                    outputBox.insertText(name + "\n")
                }
            }
            
        }
        catch {
            print("an error occured while getting data: \(error)")
        }
    }
    
    
    func saveData() {
        do {
            try myContext.save()
        }
        catch {
            print("an error occured while saving: \(error)")
        }
    }
    
}

